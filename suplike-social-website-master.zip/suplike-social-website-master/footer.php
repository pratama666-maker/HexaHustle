<script src="./lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="js/index.min.js?v1.5"></script>