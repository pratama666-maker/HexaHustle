<?php
header('Access-Control-Allow-Origin: *');
header('content-type: application/json');


require_once "app.json";