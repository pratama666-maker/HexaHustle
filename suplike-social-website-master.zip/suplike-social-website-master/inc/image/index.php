<?php
// 404
header('Status Code: 404');