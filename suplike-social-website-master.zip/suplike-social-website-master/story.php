<section class="main my-2">
    <div class="wrapper">
        <div class="left-col">
            <div class="status-wrapper ml-2">
                <!--- story cards go here---->
                <a href="./post?story" class="anchor">
                    <div class="status-card"  tabindex="0">
                        <div class="profile-pic add"><i class="fa fa-plus fa-2x"></i></div>
                        <p class="username">create</p>
                </a>
            </div>
        </div>
    </div>
</section>