<div class="tab-nav-container nav-show">
  <a href="home" class="no-style">
    <div class="tab purple">
      <i class="fas fa-home"></i>
    </div>
  </a>
  <a href="social" class="no-style">
    <div class="tab pink">
      <i class="far fa-heart"></i>
    </div>
  </a>
  <a href="search" class="no-style">
    <div class="tab yellow">
      <i class="fas fa-search"></i>
    </div>
  </a>
  <a href="notification" class="no-style">
    <div class="tab teal">
      <i class="far fa-bell"></i>
    </div>
  </a>
  <a href="profile" class="no-style">
    <div class="tab blue">
      <i class="fas fa-user"></i>
    </div>
  </a>
</div>
